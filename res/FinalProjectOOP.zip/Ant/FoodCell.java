package Ant;

import java.util.PriorityQueue;

import request.Request;

public class FoodCell implements Cell {

	@Override
	public void step(PriorityQueue<Request> requestQueue) {
		//does nothing
	}

}
