package request;

import Ant.Cell;

public class PickupRequest extends Request {

	public PickupRequest(Cell m, int[] f, int[] t) {
		super(m, f, t);
	}

}
