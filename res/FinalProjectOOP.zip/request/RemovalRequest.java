package request;
import Ant.Cell;


public class RemovalRequest extends Request {

	public RemovalRequest(Cell m, int[] f) {
		super(m, f, null);
	}

}
