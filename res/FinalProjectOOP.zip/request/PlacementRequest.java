package request;

import Ant.Cell;

public class PlacementRequest extends Request {
	public PlacementRequest(Cell m,int[] t){
		super(m, null, t);
	}
}
