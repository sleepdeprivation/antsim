package request;

import Ant.Cell;


public class MoveRequest extends Request {
	public MoveRequest(Cell r, int[] f, int[] t){
		super(r, f, t);
	}
}
