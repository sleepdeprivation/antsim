package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import Ant.Ant;
import Ant.Anthill;
import Ant.Cell;
import Ant.FoodCell;
import Pheromone.PheromoneCell;
import logic.Board;

/*
 * A class for extracting images from a Board object to be used in the UI
 */
public class BoardImageGenerator {
	
	public Board b;

	BufferedImage im;
	BufferedImage pIm;
	
	public BoardImageGenerator(Board bb){
		b = bb;
		im = new BufferedImage(b.getCols(), b.getRows(), BufferedImage.TYPE_INT_RGB);
		pIm = new BufferedImage(b.getCols(), b.getRows(), BufferedImage.TYPE_INT_ARGB);
	}

	Color white = new Color(255, 255, 255);
	Color red = new Color(255, 0, 0);
	Color blue = new Color(0, 0, 255);
	Color green = new Color(0, 255, 0);
	Color black = new Color(0, 0, 0);
	Color transparent = new Color(255, 255, 255, 0);
	
	public void whiteOut(){
		for(int ii = 0; ii < b.getRows(); ii++){
		for(int kk = 0; kk < b.getCols(); kk++){
			im.setRGB(ii, kk, white.getRGB());
		}}
	}
	
	/*
	 * print this onto an image
	 */
	public BufferedImage createIntegerBoard(){
		Cell x;
		whiteOut();
		for(int ii = 0; ii < b.getRows(); ii++){
		for(int kk = 0; kk < b.getCols(); kk++){
			x = b.get(ii, kk);
			//im.setRGB(ii, kk, white.getRGB());
			if(x instanceof Ant)
				im.setRGB(ii, kk, black.getRGB());
			else if(x instanceof FoodCell)
				im.setRGB(ii, kk, blue.getRGB());
			else if(x instanceof Anthill){
				//char[] s = Integer.toString(((Anthill) x).score).toCharArray();
				Graphics g = im.createGraphics();
				g.setColor(green);
			    //g.setFont(new Font("TimesRoman", Font.PLAIN, 80)); 
				g.drawString(Integer.toString(((Anthill) x).score), ii, kk);
				//.drawChars(s, 0, s.length, ii, kk);
				//im.setRGB(ii, kk, green.getRGB());
				/*
				int r = ((Anthill)x).radius;
				int rows = b.getRows();
				int cols = b.getCols();
				im.setRGB(	Math.max(0,  ii - r)
							,Math.max(0, kk-r)
							,Math.min(2*r, rows-1)
							,Math.min(2*r, cols-1)
							,new int[]{green.getRGB()}, 0, 1);*/
			}
		}}
		return im;
	}

	/*
	 * print this onto an image
	 */
	public BufferedImage createPheromoneImage(){
		PheromoneCell ph;
		double pconcentration;
		for(int ii = 0; ii < b.getRows(); ii++){
		for(int kk = 0; kk < b.getCols(); kk++){
			ph = (PheromoneCell) b.pheromoneMap.get(ii, kk);
			if(ph != null){
				pconcentration = ph.getNormalizedPConcentration();
				//System.out.println(pconcentration);
				if(pconcentration > 0){
					pIm.setRGB(ii, kk, new Color(255, 0, 0, (int)(pconcentration*255)).getRGB());
				}else{
					//pIm.setRGB(ii, kk, transparent.getRGB());
				}
			}
		}}
		return pIm;
	}
	
}
